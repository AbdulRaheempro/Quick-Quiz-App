const questions = [
    {
        question: "Which planet is known as the Red Planet?",
        answers: [
            { text: "Venus", correct: false },
            { text: "Mars", correct: true },
            { text: "Jupiter", correct: false },
            { text: "Saturn", correct: false }
        ]
    },
    {
        question: "Which element has the chemical symbol 'O'?",
        answers: [
            { text: "Oxygen", correct: true },
            { text: "Gold", correct: false },
            { text: "Silver", correct: false },
            { text: "Iron", correct: false }
        ]
    },
    {
        question: "What is the capital of Japan?",
        answers: [
            { text: "Lahore", correct: false },
            { text: "London", correct: false },
            { text: "Tokyo", correct: true },
            { text: "Delhi", correct: false }
        ]
    },
    {
        question: "In which year did the Titanic sink?",
        answers: [
            { text: "1912", correct: true },
            { text: "1987", correct: false },
            { text: "1923", correct: false },
            { text: "1914", correct: false }
        ]
    },
    {
        question: "Which country is known as the Land of the Rising Sun?",
        answers: [
            { text: "Japan", correct: true },
            { text: "Pakistan", correct: false },
            { text: "China", correct: false },
            { text: "USA", correct: false }
        ]
    }
];

const questionElement = document.getElementById("question");
const answerButton = document.getElementById("ans-button");
const nextButton = document.getElementById("next-btn");

let currentQuestionIndex = 0;
let score = 0;

function startquiz() {
    currentQuestionIndex = 0;
    score = 0;
    nextButton.innerHTML = "Next";
    nextButton.style.display = "none"; // Hide the Next button initially
    showquestion();
}

function showquestion() {
    let currentQuestion = questions[currentQuestionIndex];
    let questionno = currentQuestionIndex + 1;
    questionElement.innerHTML = questionno + ". " + currentQuestion.question;

    // Clear previous answer buttons
    answerButton.innerHTML = "";

    currentQuestion.answers.forEach(answer => {
        const button = document.createElement("button");
        button.innerHTML = answer.text;
        button.classList.add("btn");
        answerButton.appendChild(button);
        if (answer.correct) {
            button.dataset.correct = answer.correct;
        }
        button.addEventListener("click", selectAnswer);
    });
}

function selectAnswer(e) {
    const selectedbtn = e.target;
    const iscorrect = selectedbtn.dataset.correct === "true";

    if (iscorrect) {
        selectedbtn.classList.add("correct");
        score++; // Increment score if the answer is correct
    } else {
        selectedbtn.classList.add("incorrect");
    }

    // Disable all buttons after an answer is selected
    Array.from(answerButton.children).forEach(button => {
        button.disabled = true;
        if (button.dataset.correct === "true") {
            button.classList.add("correct"); // Highlight the correct answer
        }
    });

    // Show the Next button
    nextButton.style.display = "block";
}

// Function to handle the Next button click
nextButton.addEventListener("click", () => {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        showquestion();
        nextButton.style.display = "none"; // Hide the Next button until an answer is selected
    } else {
        showScore(); // Show the final score when the quiz ends
    }
});

function showScore() {
    // Display the final score
    questionElement.innerHTML = `You scored ${score} out of ${questions.length}!`;

    // Hide the answer buttons and show the Restart button
    answerButton.innerHTML = "";
    nextButton.innerHTML = "Restart";
    nextButton.style.display = "block";
    nextButton.addEventListener("click", startquiz); // Restart the quiz
}

// Start the quiz
startquiz();
